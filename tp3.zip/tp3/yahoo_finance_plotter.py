import datetime
from dateutil import tz
import urllib.request
import json
import sys
import matplotlib.pyplot as plt


############################# FUNCIONES AUXILIARES DEFINIDAS POR EL GRUPO ############################### 

def get_quote_json(q, init_date, end_date, interval):
    '''Accede a la API de Yahoo! Finance para la accion "q", con la fecha de inciio, fin, e intervalo correspondiente
    y devuelve el JSON (dict) correspondiente.'''
    pass

############################# FUNCIONES AUXILIARES DEFINIDAS POR LA CATEDRA ############################### 
def to_date(strdate):
    '''toma un string en formato %Y-%m-%d y lo convierte a algo de tipo fecha'''
    return datetime.datetime.strptime(strdate, '%Y-%m-%d')

def to_ymd(ts):
    ''' Toma un timestamp y lo convierte a un string con formato %Y-%m-%d'''
    return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')

def to_posix_timestamp(date):
    '''Toma un datetime y lo convierte a timestamp formato POSIX'''
    return (date - datetime.datetime.utcfromtimestamp(0)).total_seconds() + 14400


############################# FUNCION PRINCIPAL ############################### 
def main():
    ''' Es la funcion principal donde se ejecuta nuestro programa.'''

    # Leemos el archivo input.cfg con los parametros para la ejecucion.


    # Recordar que las fechas estan en formato yyyy-mm-dd
    # Recordar que los posibles valores para el intevalo son los siguientes:
    # ["1d","5d","1wk","1mo","3mo","6mo","1y","2y","5y","10y","ytd","max"]

    # Obtenemos las fechas de inicio y fin, el intervalo, y las acciones a analizar.
    # Las guardamos en quotes.
    quotes = None

    for q in quotes:
        pass
        # Obtenemos el JSON.

        # Extraemos y procesamos la informacion.

        # Agregamos el grafico de la serie.

        # Calculamos las metricas

    # Agregamos la leyenda al grafico.

    # Hacemos show del grafico.

if __name__ == '__main__':
    main()

